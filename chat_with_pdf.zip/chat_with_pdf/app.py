from flask import Flask, request, jsonify, render_template, send_from_directory
import os
import uuid

from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.document_loaders import PyMuPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

from langchain.llms import CTransformers
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory

# ---------------- Flask Setup ----------------
app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ---------------- Models ----------------
print("Loading Embedding Model (Fast version)…")
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/paraphrase-MiniLM-L3-v2"
)

print("Loading TinyLlama Model (CTransformers)…")
llm = CTransformers(
    model="./models/TinyLlama-1.1B-Chat-v1.0.Q4_0.gguf",
    model_type="llama",
    config={
        "temperature": 0.3,
        "max_new_tokens": 256
    }
)

# ---------------- Memory ----------------
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# ---------------- Global Variables ----------------
db = None
qa_chain = None

# ---------------- Routes ----------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


# ---------------- PDF Upload ----------------
@app.route("/upload", methods=["POST"])
def upload_pdf():
    global db, qa_chain, memory

    file = request.files.get("pdf")
    if not file:
        return jsonify({"error": "No file uploaded"}), 400

    filename = str(uuid.uuid4()) + ".pdf"
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)

    # Load PDF
    loader = PyMuPDFLoader(filepath)
    documents = loader.load()

    # Split text
    splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    docs = splitter.split_documents(documents)

    # Create vector DB
    db = FAISS.from_documents(docs, embeddings)

    # Create QA chain
    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=db.as_retriever(),
        memory=memory
    )

    return jsonify({"message": "PDF uploaded and processed successfully!", "filename": filename})


# ---------------- Chat ----------------
@app.route("/chat", methods=["POST"])
def chat():
    global qa_chain
    if not qa_chain:
        return jsonify({"response": "Please upload a PDF first."}), 400

    user_msg = request.json.get("message", "").strip()
    if not user_msg:
        return jsonify({"response": "Empty message."}), 400

    try:
        response = qa_chain.run(user_msg)
        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"response": f"[Error] {str(e)}"}), 500


# ---------------- Run App ----------------
if __name__ == "__main__":
    app.run(debug=True)
